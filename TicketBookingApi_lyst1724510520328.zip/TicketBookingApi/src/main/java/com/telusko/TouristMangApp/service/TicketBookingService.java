package com.telusko.TouristMangApp.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telusko.TouristMangApp.dao.ITicketRepo;
import com.telusko.TouristMangApp.model.Passenger;

@Service
public class TicketBookingService implements ITicketBookingService 
{
	@Autowired
	private ITicketRepo repo;

	@Override
	public Passenger registerPassenger(Passenger passenger) 
	{
		
		return repo.save(passenger);
	}

	@Override
	public Passenger fetchPassengerDetails(Integer id) 
	{
		Optional<Passenger> optional = repo.findById(id);
		
		return optional.get();
	}

}
