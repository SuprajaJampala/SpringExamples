package com.telusko.TouristMangApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TouristMangAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
