package com.telusko.CRMTh.service;

import com.telusko.CRMTh.model.Passenger;
import com.telusko.CRMTh.model.Ticket;

public interface ITicketBookingService 
{
	
	public Ticket registerPassenger(Passenger passenger);
	public Ticket getFullTicketInfo(Integer ticketNumber);

}
