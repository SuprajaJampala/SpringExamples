package com.telusko.CRMTh.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.telusko.CRMTh.model.Passenger;
import com.telusko.CRMTh.model.Ticket;

@Service
public class TicketBookingService implements ITicketBookingService 
{

	private String BOOKING_URL="http://localhost:8585/TicketBookingAPI/api/book-ticket/getTicketNumber";
	private String GET_URL="http://localhost:8585/TicketBookingAPI/api/book-ticket/getTicket/{ticketNumber}";

	@Override
	public Ticket registerPassenger(Passenger passenger) 
	{
//		RestTemplate restTemplate=new RestTemplate();
//		ResponseEntity<Ticket> response = restTemplate.postForEntity(BOOKING_URL, passenger, Ticket.class);
//		return response.getBody();
		
		WebClient webClient = WebClient.create();
		
		Ticket ticket=webClient.post()
		.uri(BOOKING_URL)
		.bodyValue(passenger)
		.retrieve()
		.bodyToMono(Ticket.class)
		.block();
		
		return ticket;
		
		
//		String str="Telusko";
//		String str2=str.toUpperCase();
//		int lentgh=str2.length();
//		str.toUpperCase().toLowerCase().length();
		
	}

	@Override
	public Ticket getFullTicketInfo(Integer ticketNumber) 
	{
//		RestTemplate restTemplate=new RestTemplate();
//		ResponseEntity<Ticket> response=restTemplate.getForEntity(GET_URL, Ticket.class, ticketNumber);
//		Ticket ticket=response.getBody();
//		return ticket;
		
		WebClient webClient = WebClient.create();
		
		Ticket ticket=webClient.get()
		.uri(GET_URL, ticketNumber)
		.retrieve()
		.bodyToMono(Ticket.class)
		.block();
		
		return ticket;
	}

}
